<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
         <link rel="stylesheet" href="health.css">
        <title>Test Form</title>
        <style>
            * {
                font-size: 20px;
            }
        </style>
    </head>
    <body>
        <form action="f_report.php" method="POST">
            <input
                type="radio"
                name="BMI"
                id="underweight"
                value="underweight"
                required
            />
            <label for="underweight">Below 18.5</label><br />
            <input
                type="radio"
                name="BMI"
                id="normal"
                value="normal"
                required
            />
            <label for="normal">Between 18.5 and 24.9</label><br />
            <input
                type="radio"
                name="BMI"
                id="overweight"
                value="overweight"
                required
            />
            <label for="overweight">Between 25 and 29.9</label><br />
            <input type="radio" name="BMI" id="obese" value="obese" required />
            <label for="obese">Between 30 and 39.9</label><br /><br />

            <input type="submit" value="Check Health Stats" name="submit" />


        </form>

    </body>
</html>
