<?php


            if(isset($_POST['submit'])) {
                $weight = $_POST['BMI'];
                echo "<br>";
                if($weight == "underweight")
                    echo "<div style=\"color: white\">You are underweight</div>";
                else if($weight == "normal")
                    echo "<div style=\"color: white\">You are normal</div>";
                else if($weight == "overweight")
                    echo "<div style=\"color: white\">You are overweight</div>";
                else if($weight == "obese")
                    echo "<div style=\"color: white\">You are obese</div>";
                else
                    echo "<div>Something went wrong!</div>";
            }
        ?>


        <?php
        if(isset($_POST['submit'])) {
                        $time = $_POST['breath'];
                        echo "<br>";
                        if($time == "Check your lungs condition through MRI or CT-Scan since you may have a fatal lung problem.")
                            echo "<div style=\"color: white\">Check your lungs condition through MRI or CT-Scan since you may have a fatal lung problem.</div>";
                        else if($time == "You have less efficient respiration, try to do some breathing exercises to improve your respiration efficiency.")
                            echo "<div style=\"color: white\">You have less efficient respiration, try to do some breathing exercises to improve your respiration efficiency.</div>";
                        else if($time == "Your lungs are normal just try to maintain it by doing some breathing exercises.")
                            echo "<div style=\"color: white\">Your lungs are normal just try to maintain it by doing some breathing exercises.</div>";
                        else if($time == "Your lungs have good respiration efficiency.")
                            echo "<div style=\"color: white\">Your lungs have good respiration efficiency.</div>";
                        else
                            echo "<div>Something went wrong!</div>";
                    }
        ?>





                <?php
                if(isset($_POST['submit'])) {
                                $lungs = $_POST['chest'];
                                echo "<br>";
                                if($lungs == "Check your lungs and heart through MRI or CT-Scan since you may have a serious problem related to lungs or heart.")
                                    echo "<div style=\"color: white\">Check your lungs and heart through MRI or CT-Scan since you may have a serious problem related to lungs or heart./div>";
                                else if($lungs == "You have less chest expansion try to do some breathing exercises and improve it.")
                                    echo "<div style=\"color: white\">You have less chest expansion try to do some breathing exercises and improve it.</div>";
                                else if($lungs == "Your chest is normal just try to maintain it by doing some breathing exercises.")
                                    echo "<div style=\"color: white\">Your chest is normal just try to maintain it by doing some breathing exercises.</div>";
                                else if($lungs == "You have a great chest expansion.")
                                    echo "<div style=\"color: white\">You have a great chest expansion.</div>";
                                else
                                    echo "<div>Something went wrong!</div>";
                            }
                ?>


                <?php
                                if(isset($_POST['submit'])) {
                                                $pain = $_POST['joints'];
                                                echo "<br>";
                                                if($pain == "It's normal try to do some sit-ups daily to keep your knee in a better state.")
                                                    echo "<div style=\"color: white\">It's normal try to do some sit-ups daily to keep your knee in a better state.</div>";
                                                else if($pain == "It's due to calcium and phosphorus deficiency. You can either consume calcium tablets or take intake of calcium and phosphorus rich diet like milk or spinach to overcome but this might take 3-4 weeks.")
                                                    echo "<div style=\"color: white\">It's due to calcium and phosphorus deficiency. You can either consume calcium tablets or take intake of calcium and phosphorus rich diet like milk or spinach to overcome but this might take 3-4 weeks.</div>";
                                                else if($pain == "You Joints are in good condition, you dont have calcium or phosphorus efficiency.")
                                                    echo "<div style=\"color: white\">You Joints are in good condition, you dont have calcium or phosphorus efficiency.</div>";
                                                else if($pain == "Your joints are normal, just take proper medical care of it.")
                                                    echo "<div style=\"color: white\">Your joints are normal, just take proper medical care of it.</div>";
                                                else
                                                    echo "<div>Something went wrong!</div>";
                                            }
                                ?>



                                 <?php
                                                                if(isset($_POST['submit'])) {
                                                                                $c_p = $_POST['chest_pain'];
                                                                                echo "<br>";
                                                                                if($c_p == "A")
                                                                                    echo "<div style=\"color: white\">You are A</div>";
                                                                                else if($c_p == "B")
                                                                                    echo "<div style=\"color: white\">You are B</div>";
                                                                                else if($c_p == "C")
                                                                                    echo "<div style=\"color: white\">You are C</div>";
                                                                                else if($c_p == "D")
                                                                                    echo "<div style=\"color: white\">You are D</div>";
                                                                                else
                                                                                    echo "<div>Something went wrong!</div>";
                                                                            }
                                                                ?>


                                                                 <?php
                                                                                                                                if(isset($_POST['submit'])) {
                                                                                                                                                $drink = $_POST['water'];
                                                                                                                                                echo "<br>";
                                                                                                                                                if($drink == "A")
                                                                                                                                                    echo "<div style=\"color: white\">You are A</div>";
                                                                                                                                                else if($drink == "B")
                                                                                                                                                    echo "<div style=\"color: white\">You are B</div>";
                                                                                                                                                else if($drink == "C")
                                                                                                                                                    echo "<div style=\"color: white\">You are C</div>";
                                                                                                                                                else if($drink == "D")
                                                                                                                                                    echo "<div style=\"color: white\">You are D</div>";
                                                                                                                                                else
                                                                                                                                                    echo "<div>Something went wrong!</div>";
                                                                                                                                            }
                                                                                                                                ?>

                                                                                                                                 <?php
                                                                                                                                                                                                                                                                if(isset($_POST['submit'])) {
                                                                                                                                                                                                                                                                                $tired = $_POST['work'];
                                                                                                                                                                                                                                                                                echo "<br>";
                                                                                                                                                                                                                                                                                if($tired == "A")
                                                                                                                                                                                                                                                                                    echo "<div style=\"color: white\">You are A</div>";
                                                                                                                                                                                                                                                                                else if($tired == "B")
                                                                                                                                                                                                                                                                                    echo "<div style=\"color: white\">You are B</div>";
                                                                                                                                                                                                                                                                                else if($tired == "C")
                                                                                                                                                                                                                                                                                    echo "<div style=\"color: white\">You are C</div>";
                                                                                                                                                                                                                                                                                else if($tired == "D")
                                                                                                                                                                                                                                                                                    echo "<div style=\"color: white\">You are D</div>";
                                                                                                                                                                                                                                                                                else
                                                                                                                                                                                                                                                                                    echo "<div>Something went wrong!</div>";
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                ?>




     <?php
                                                                                                                                                                                                                                                                    if(isset($_POST['submit'])) {
                                                                                                                                                                                                                                                                                    $m_p = $_POST['muscle'];
                                                                                                                                                                                                                                                                                    echo "<br>";
                                                                                                                                                                                                                                                                                    if($m_p == "A")
                                                                                                                                                                                                                                                                                        echo "<div style=\"color: white\">You are A</div>";
                                                                                                                                                                                                                                                                                    else if($m_p == "B")
                                                                                                                                                                                                                                                                                        echo "<div style=\"color: white\">You are B</div>";
                                                                                                                                                                                                                                                                                    else if($m_p == "C")
                                                                                                                                                                                                                                                                                        echo "<div style=\"color: white\">You are C</div>";
                                                                                                                                                                                                                                                                                    else if($m_p == "D")
                                                                                                                                                                                                                                                                                        echo "<div style=\"color: white\">You are D</div>";
                                                                                                                                                                                                                                                                                    else
                                                                                                                                                                                                                                                                                        echo "<div>Something went wrong!</div>";
                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                    ?>













