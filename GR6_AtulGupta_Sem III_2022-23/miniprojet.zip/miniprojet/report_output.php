



    <?php


    if(isset($_POST['submit'])) {
    if(isset($_POST['radio'])=="Radio 1")
    {
     echo " your bmi is : A";

    }
    else if(isset($_POST['radio'])=="Radio 2")
    {
     echo " your bmi is : B";
    }
    else if(isset($_POST['radio']=="Radio 3")
    {
     echo "your bmi is : C";
    }
    else
    {
    echo "you have not selected any option";
    }

    }


    ?>