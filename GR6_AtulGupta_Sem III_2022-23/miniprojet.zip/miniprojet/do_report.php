<?php


            if(isset($_POST['submit'])) {
                $weight = $_POST['BMI'];
                echo "<br>";
                if($weight == "A")
                    echo "<div style=\"color: white\">You are A</div>";
                else if($weight == "B")
                    echo "<div style=\"color: white\">You are B</div>";
                else if($weight == "C")
                    echo "<div style=\"color: white\">You are C</div>";
                else if($weight == "obese")
                    echo "<div style=\"color: white\">D</div>";
                else
                    echo "<div>Something went wrong!</div>";
            }
        ?>


        <?php
        if(isset($_POST['submit'])) {
                        $time = $_POST['breath'];
                        echo "<br>";
                        if($time == "A")
                            echo "<div style=\"color: white\">You are A</div>";
                        else if($time == "B")
                            echo "<div style=\"color: white\">You are B</div>";
                        else if($time == "C")
                            echo "<div style=\"color: white\">You are C</div>";
                        else if($time == "D")
                            echo "<div style=\"color: white\">You are D</div>";
                        else
                            echo "<div>Something went wrong!</div>";
                    }
        ?>





                <?php
                if(isset($_POST['submit'])) {
                                $lungs = $_POST['chest'];
                                echo "<br>";
                                if($lungs == "A")
                                    echo "<div style=\"color: white\">You are A</div>";
                                else if($lungs == "B")
                                    echo "<div style=\"color: white\">You are B</div>";
                                else if($lungs == "C")
                                    echo "<div style=\"color: white\">You are C</div>";
                                else if($lungs == "D")
                                   echo "<div style=\"color: white\">You are D</div>";
                                else
                                    echo "<div>Something went wrong!</div>";
                            }
                ?>


                <?php
                                if(isset($_POST['submit'])) {
                                                $pain = $_POST['joints'];
                                                echo "<br>";
                                                if($pain == "A")
                                                    echo "<div style=\"color: white\">You are A</div>";
                                                else if($pain == "B")
                                                    echo "<div style=\"color: white\">You are B</div>";
                                                else if($pain == "C")
                                                    echo "<div style=\"color: white\">You are C</div>";
                                                else if($pain == "D")
                                                    echo "<div style=\"color: white\">You are D</div>";
                                                else
                                                    echo "<div>Something went wrong!</div>";
                                            }
                                ?>



                                 <?php
                                                                if(isset($_POST['submit'])) {
                                                                                $c_p = $_POST['chest_pain'];
                                                                                echo "<br>";
                                                                                if($c_p == "A")
                                                                                    echo "<div style=\"color: white\">You are A</div>";
                                                                                else if($c_p == "B")
                                                                                    echo "<div style=\"color: white\">You are B</div>";
                                                                                else if($c_p == "C")
                                                                                    echo "<div style=\"color: white\">You are C</div>";
                                                                                else if($c_p == "D")
                                                                                    echo "<div style=\"color: white\">You are D</div>";
                                                                                else
                                                                                    echo "<div>Something went wrong!</div>";
                                                                            }
                                                                ?>


                                                                 <?php
                                                                                                                                if(isset($_POST['submit'])) {
                                                                                                                                                $drink = $_POST['water'];
                                                                                                                                                echo "<br>";
                                                                                                                                                if($drink == "A")
                                                                                                                                                    echo "<div style=\"color: white\">You are A</div>";
                                                                                                                                                else if($drink == "B")
                                                                                                                                                    echo "<div style=\"color: white\">You are B</div>";
                                                                                                                                                else if($drink == "C")
                                                                                                                                                    echo "<div style=\"color: white\">You are C</div>";
                                                                                                                                                else if($drink == "D")
                                                                                                                                                    echo "<div style=\"color: white\">You are D</div>";
                                                                                                                                                else
                                                                                                                                                    echo "<div>Something went wrong!</div>";
                                                                                                                                            }
                                                                                                                                ?>

                                                                                                                                 <?php
                                                                                                                                                                                                                                                                if(isset($_POST['submit'])) {
                                                                                                                                                                                                                                                                                $tired = $_POST['work'];
                                                                                                                                                                                                                                                                                echo "<br>";
                                                                                                                                                                                                                                                                                if($tired == "A")
                                                                                                                                                                                                                                                                                    echo "<div style=\"color: white\">You are A</div>";
                                                                                                                                                                                                                                                                                else if($tired == "B")
                                                                                                                                                                                                                                                                                    echo "<div style=\"color: white\">You are B</div>";
                                                                                                                                                                                                                                                                                else if($tired == "C")
                                                                                                                                                                                                                                                                                    echo "<div style=\"color: white\">You are C</div>";
                                                                                                                                                                                                                                                                                else if($tired == "D")
                                                                                                                                                                                                                                                                                    echo "<div style=\"color: white\">You are D</div>";
                                                                                                                                                                                                                                                                                else
                                                                                                                                                                                                                                                                                    echo "<div>Something went wrong!</div>";
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                ?>




     <?php
                                                                                                                                                                                                                                                                    if(isset($_POST['submit'])) {
                                                                                                                                                                                                                                                                                    $m_p = $_POST['muscle'];
                                                                                                                                                                                                                                                                                    echo "<br>";
                                                                                                                                                                                                                                                                                    if($m_p == "A")
                                                                                                                                                                                                                                                                                        echo "<div style=\"color: white\">You are A</div>";
                                                                                                                                                                                                                                                                                    else if($m_p == "B")
                                                                                                                                                                                                                                                                                        echo "<div style=\"color: white\">You are B</div>";
                                                                                                                                                                                                                                                                                    else if($m_p == "C")
                                                                                                                                                                                                                                                                                        echo "<div style=\"color: white\">You are C</div>";
                                                                                                                                                                                                                                                                                    else if($m_p == "D")
                                                                                                                                                                                                                                                                                        echo "<div style=\"color: white\">You are D</div>";
                                                                                                                                                                                                                                                                                    else
                                                                                                                                                                                                                                                                                        echo "<div>Something went wrong!</div>";
                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                    ?>

      <?php


                  if(isset($_POST['submit'])) {
                      $e_r = $_POST['eyes'];
                      echo "<br>";
                      if($e_r == "A")
                          echo "<div style=\"color: white\">You are A</div>";
                      else if($e_r == "B")
                          echo "<div style=\"color: white\">You are B</div>";
                      else if($e_r == "C")
                          echo "<div style=\"color: white\">You are C</div>";
                      else if($weight == "obese")
                          echo "<div style=\"color: white\">D</div>";
                      else
                          echo "<div>Something went wrong!</div>";
                  }
              ?>




              <?php


                          if(isset($_POST['submit'])) {
                              $gs_r = $_POST['gs'];
                              echo "<br>";
                              if($gs_r == "A")
                                  echo "<div style=\"color: white\">You are A</div>";
                              else if($gs_r == "B")
                                  echo "<div style=\"color: white\">You are B</div>";
                              else if($gs_r == "C")
                                  echo "<div style=\"color: white\">You are C</div>";
                              else if($weight == "obese")
                                  echo "<div style=\"color: white\">D</div>";
                              else
                                  echo "<div>Something went wrong!</div>";
                          }
                      ?>



                     <?php
                      //echo " <div class=\"abc\">Maximum number of A means your body nature is vata.</div>";

                      ?>


                      <?php
                                           // echo "<div class=\"abc\"> Maximum number of B means your body nature is pitta.</div>";

                                            ?>


<?php
                     // echo " <div class=\"abc\">Maximum number of C means your body nature is kapha.</div>";

                      ?>














