<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="health.css">
    <title>Survey Form</title>
</head>
<body>
<div class="container ">
    <header class="header">
        <h1 id="title">
            HEALTH REPORT
        </h1>
        <p id="description">
            Higher standards of care everyday
        </p>
    </header>
    <form action="f_report.php"  method="POST" id="HEALTH REPORT">

        <!-- Text section -->
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" class="formControl" placeholder="Enter your name" required>
        </div>
        <!-- end of text section -->

        <!-- Type Email section -->
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" class="formControl" placeholder="Enter your Email" required>
        </div>
        <!-- end of Email section -->

        <!-- Type Number section -->
    <!--    <div class="form-group">
            <label for="phone">Phone Number</label>
            <input type="phone" name="phone" id="phone" class="formControl" placeholder="Enter your phone number" required>
        </div> -->
        <!-- end of Number section -->


        <!-- select section -->
        <div class="form-group">
            <p id="quest">1.  Please enter your gender</p>
            <select name="Gender"
                    id="dropdown"
                    class="formControl required">
                <option value="" disabled
                        selected>Select your gender</option>
                <option
                        value="Male">Male</option>
                <option
                        value="Female">Female</option>
                <option
                        value="Prefer not to say">Prefer not to say</option>
            </select>

        </div>
        <div class="form-group">
            <p id="quest">2.  Enter your Age</p>
            <select name="Age"
                    id="dropdown"
                    class="formControl required">
                <option value="" disabled
                        selected>Select your Age</option>
                <option
                        value="Less than 18">Less than 18</option>
                <option
                        value="Between 18-39">Between 18-39</option>
                <option
                        value="Between 40-60">Between 40-60</option>
                <option
                        value="Greater than 60">Greater than 60</option>
            </select>
        </div>
        <!-- end of select section -->

        <!-- radio buttons -->


       <p id="quest">3.  Enter your BMI range</p>
       <input
                       type="radio"
                       name="BMI"
                       id="underweight"
                       value="underweight"
                       required
                   />
                   <label for="underweight">Below 18.5</label><br />
                   <input
                       type="radio"
                       name="BMI"
                       id="normal"
                       value="normal"
                       required
                   />
                   <label for="normal">Between 18.5 and 24.9</label><br />
                   <input
                       type="radio"
                       name="BMI"
                       id="overweight"
                       value="overweight"
                       required
                   />
                   <label for="overweight">Between 25 and 29.9</label><br />
                   <input type="radio" name="BMI" id="obese" value="obese" required />
                   <label for="obese">Between 30 and 39.9</label><br /><br />






   <p id="quest">4.  How much time you can hold your breath?Choose from the given range and all values are in seconds.</p>
                   <input

                                   type="radio"
                                   name="breath"
                                   id="Check your lungs condition through MRI or CT-Scan since you may have a fatal lung problem."
                                   value="Check your lungs condition through MRI or CT-Scan since you may have a fatal lung problem."
                                   required
                               />
                               <label for="Check your lungs condition through MRI or CT-Scan since you may have a fatal lung problem.">Less than 25.</label><br />
                               <input
                                   type="radio"
                                   name="breath"
                                   id="You have less efficient respiration, try to do some breathing exercises to improve your respiration efficiency."
                                   value="You have less efficient respiration, try to do some breathing exercises to improve your respiration efficiency."
                                   required
                               />
                               <label for="You have less efficient respiration, try to do some breathing exercises to improve your respiration efficiency.">Between 25-40.</label><br />
                               <input
                                   type="radio"
                                   name="breath"
                                   id="It's normal just try to maintain it by doing some breathing exercises."
                                   value="Your lungs are normal just try to maintain it by doing some breathing exercises."
                                   required
                               />
                               <label for="Your lungs are normal just try to maintain it by doing some breathing exercises.">Between 40-90.</label><br />
                               <input
                                type="radio"
                                name="breath"
                                id="Your lungs have good respiration efficiency."
                                value="Your lungs have good respiration efficiency."
                                required
                                  />
                               <label for="Your lungs have good respiration efficiency.">Greater than 90.</label><br /><br />





                               <p id="quest">5.  How much your chest Expands when you inhale?Choose from the given range.</p>

<input

                                   type="radio"
                                   name="chest"
                                   id="Check your lungs and heart through MRI or CT-Scan since you may have a serious problem related to lungs or heart."
                                   value="Check your lungs and heart through MRI or CT-Scan since you may have a serious problem related to lungs or heart."
                                   required
                               />
                               <label for="Check your lungs and heart through MRI or CT-Scan since you may have a serious problem related to lungs or heart.">Less  than 2cm.</label><br />
                               <input
                                   type="radio"
                                   name="chest"
                                   id="You have less chest expansion try to do some breathing exercises and improve it."
                                   value="You have less chest expansion try to do some breathing exercises and improve it."
                                   required
                               />
                               <label for="You have less chest expansion try to do some breathing exercises and improve it.">Between 2cm-4cm.</label><br />
                               <input
                                   type="radio"
                                   name="chest"
                                   id="Your chest is normal just try to maintain it by doing some breathing exercises."
                                   value="Your chest is normal just try to maintain it by doing some breathing exercises."
                                   required
                               />
                               <label for="Your chest is normal just try to maintain it by doing some breathing exercises.">Between 4cm-8cm.</label><br />
                               <input
                                type="radio"
                                name="chest"
                                id="You have a great chest expansion."
                                value="You have a great chest expansion."
                                required
                                  />
                               <label for="You have a great chest expansion.">More than 8cm.</label><br /><br />



                               <p id="quest">6.  Do you feel any pain in your Joints?(Joints means knees and elbows).</p>

                               <input

                                                                  type="radio"
                                                                  name="joints"
                                                                  id="It's normal try to do some sit-ups daily to keep your knee in a better state."
                                                                  value="It's normal try to do some sit-ups daily to keep your knee in a better state."
                                                                  required
                                                              />
                                                              <label for="It's normal try to do some sit-ups daily to keep your knee in a better state.">Yes ,sometimes but it pain rarely.</label><br />
                                                              <input
                                                                  type="radio"
                                                                  name="joints"
                                                                  id="It's due to calcium and phosphorus deficiency. You can either consume calcium tablets or take intake of calcium and phosphorus rich diet like milk or spinach to overcome but this might take 3-4 weeks."
                                                                  value="It's due to calcium and phosphorus deficiency. You can either consume calcium tablets or take intake of calcium and phosphorus rich diet like milk or spinach to overcome but this might take 3-4 weeks."
                                                                  required
                                                              />
                                                              <label for="It's due to calcium and phosphorus deficiency. You can either consume calcium tablets or take intake of calcium and phosphorus rich diet like milk or spinach to overcome but this might take 3-4 weeks.">Yes ,it has been paining from more than a week.</label><br />
                                                              <input
                                                                  type="radio"
                                                                  name="joints"
                                                                  id="You Joints are in good condition, you dont have calcium or phosphorus efficiency."
                                                                  value="You Joints are in good condition, you dont have calcium or phosphorus efficiency."
                                                                  required
                                                              />
                                                              <label for="You Joints are in good condition, you dont have calcium or phosphorus efficiency.">No ,it is not paining.</label><br />
                                                              <input
                                                               type="radio"
                                                               name="joints"
                                                               id="Your joints are normal, just take proper medical care of it."
                                                               value="Your joints are normal, just take proper medical care of it."
                                                               required
                                                                 />
                                                              <label for="Your joints are normal, just take proper medical care of it.">Yes ,it is paining but due to an injury.</label><br /><br />


 <p id="quest">7.  Do you feel any pain in chest area?</p>

  <input

                                                                   type="radio"
                                                                   name="chest_pain"
                                                                   id="A"
                                                                   value="A"
                                                                   required
                                                               />
                                                               <label for="A">Yes ,experiencing a slight pain in whole chest area.</label><br />
                                                               <input
                                                                   type="radio"
                                                                   name="chest_pain"
                                                                   id="B"
                                                                   value="B"
                                                                   required
                                                               />
                                                               <label for="B">Yes ,some pain in left chest area.</label><br />
                                                               <input
                                                                   type="radio"
                                                                   name="chest_pain"
                                                                   id="C"
                                                                   value="C"
                                                                   required
                                                               />
                                                               <label for="C">Yes , it is due to some previous surgery or injury.</label><br />
                                                               <input
                                                                type="radio"
                                                                name="chest_pain"
                                                                id="D"
                                                                value="D"
                                                                required
                                                                  />
                                                               <label for="D">No , I am not feeling any pain in chest.</label><br /><br />


             <p id="quest">8.  How much water do you drink daily?</p>

             <input
                                                                                type="radio"
                                                                                name="water"
                                                                                id="A"
                                                                                value="A"
                                                                                required
                                                                            />
                                                                            <label for="A">Less than 3 glass.</label><br />
                                                                            <input
                                                                                type="radio"
                                                                                name="water"
                                                                                id="B"
                                                                                value="B"
                                                                                required
                                                                            />
                                                                            <label for="B">Between 3-5 glass.</label><br />
                                                                            <input
                                                                                type="radio"
                                                                                name="water"
                                                                                id="C"
                                                                                value="C"
                                                                                required
                                                                            />
                                                                            <label for="C">Between 5-8 glass.</label><br />
                                                                            <input
                                                                             type="radio"
                                                                             name="water"
                                                                             id="D"
                                                                             value="D"
                                                                             required
                                                                               />
                                                                            <label for="D">More than 8 glass.</label><br /><br />


  <p id="quest">9.  After how much time of doing work continuosly you get tired?</p>

   <input
                                                                                  type="radio"
                                                                                  name="work"
                                                                                  id="A"
                                                                                  value="A"
                                                                                  required
                                                                              />
                                                                              <label for="A">Less than 2 hrs.</label><br />
                                                                              <input
                                                                                  type="radio"
                                                                                  name="work"
                                                                                  id="B"
                                                                                  value="B"
                                                                                  required
                                                                              />
                                                                              <label for="B">Between 2-3 hrs.</label><br />
                                                                              <input
                                                                                  type="radio"
                                                                                  name="work"
                                                                                  id="C"
                                                                                  value="C"
                                                                                  required
                                                                              />
                                                                              <label for="C">Between 3-4.5 hrs.</label><br />
                                                                              <input
                                                                               type="radio"
                                                                               name="work"
                                                                               id="D"
                                                                               value="D"
                                                                               required
                                                                                 />
                                                                              <label for="D">After 4.5 hrs.</label><br /><br />


     <p id="quest">10.  Do you feel any pain in muscles?</p>

      <input
                                                                                       type="radio"
                                                                                       name="muscle"
                                                                                       id="A"
                                                                                       value="A"
                                                                                       required
                                                                                   />
                                                                                   <label for="A">Yes ,in shoulder and neck region.</label><br />
                                                                                   <input
                                                                                       type="radio"
                                                                                       name="muscle"
                                                                                       id="B"
                                                                                       value="B"
                                                                                       required
                                                                                   />
                                                                                   <label for="B">Yes ,in thigh and in area near backbone.</label><br />
                                                                                   <input
                                                                                       type="radio"
                                                                                       name="muscle"
                                                                                       id="C"
                                                                                       value="C"
                                                                                       required
                                                                                   />
                                                                                   <label for="C">Yes ,in legs and arms.</label><br />
                                                                                   <input
                                                                                    type="radio"
                                                                                    name="muscle"
                                                                                    id="D"
                                                                                    value="D"
                                                                                    required
                                                                                      />
                                                                                   <label for="D">No ,I don't feel any noticable pain.</label><br /><br />














<input type="submit" value="Check Health Stats" name="submit" />
