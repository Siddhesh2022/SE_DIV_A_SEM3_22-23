<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="health.css">
    <title>Survey Form</title>
    <style>
    .report
    {
    color: green;
    text-shadow: 1px 0 #fff, -1px 0 #fff, 0 1px #fff, 0 -1px #fff,
                 1px 1px #fff, -1px -1px #fff, 1px -1px #fff, -1px 1px #fff;
    width: 500px;
    margin: 20px auto;
    text-align: center;
    }

    .report-wrapper
    {
    padding:0 150px;
    }
    </style>
</head>
<body>
<div class="container ">
    <header class="header">
        <h1 id="title">
            DOSHA REPORT
        </h1>
        <p id="description">
            Higher standards of care everyday
        </p>
    </header>

    <?php include 'do_report.php'; ?>

    <div class="report-wrapper">

     <div class="report">Maximum number of A means your body nature is vata.</div>

     <div class="report">Maximum number of B means your body nature is pitta.</div>

     <div class="report">Maximum number of C means your body nature is kapha.</div>
    </div>
