<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="dosha.css">
    <title>Survey Form</title>
</head>
<body>
<div class="container ">
    <header class="header">
        <h1 id="title">
            DOSHA REPORT
        </h1>
        <p id="description">
            Higher standards of care everyday
        </p>
    </header>
    <form action="doshafinal.php"  method="POST" id="HEALTH REPORT">


            <!-- radio buttons -->


           <p id="quest">1. Body Frame.</p>
           <input
                           type="radio"
                           name="BMI"
                           id="A"
                           value="A"
                           required
                       />
                       <label for="A">Thin bony and small framed hardly gain weight.</label><br />
                       <input
                           type="radio"
                           name="BMI"
                           id="B"
                           value="B"
                           required
                       />
                       <label for="B">Medium built can gain or lose weight easily</label><br />
                       <input
                           type="radio"
                           name="BMI"
                           id="C"
                           value="C"
                           required
                       />
                       <label for="C">Large built. Gain weight easily but difficult to lose.</label><br />
                    <!--   <input type="radio" name="BMI" id="obese" value="obese" required />
                       <label for="obese">Between 30 and 39.9</label><br /><br />   -->






       <p id="quest">2. Walk and Talk.</p>
                       <input

                                       type="radio"
                                       name="breath"
                                       id="A"
                                       value="A"
                                       required
                                   />
                                   <label for="A">Fast walk and Talk.</label><br />
                                   <input
                                       type="radio"
                                       name="breath"
                                       id="B"
                                       value="B"
                                       required
                                   />
                                   <label for="B">Moderate and determined walk.</label><br />
                                   <input
                                       type="radio"
                                       name="breath"
                                       id="C"
                                       value="C"
                                       required
                                   />
                                   <label for="C">Slow and steady walk.</label><br />
                          <!--         <input
                                    type="radio"
                                    name="breath"
                                    id="D"
                                    value="D"
                                    required
                                      />
                                   <label for="D">Greater than 90.</label><br /><br /> -->





                                   <p id="quest">3. Weather reaction.</p>

    <input

                                       type="radio"
                                       name="chest"
                                       id="A"
                                       value="A"
                                       required
                                   />
                                   <label for="A">Enjoy warm climate but feel uncomfortable in cool weather.</label><br />
                                   <input
                                       type="radio"
                                       name="chest"
                                       id="B"
                                       value="B"
                                       required
                                   />
                                   <label for="B">Enjoy cool weather and dislike warm weather.</label><br />
                                   <input
                                       type="radio"
                                       name="chest"
                                       id="C"
                                       value="C"
                                       required
                                   />
                                   <label for="C">Comfortable for most of the year but prefer summer and spring. Don't like damp climate.</label><br />
                                 <!--  <input
                                    type="radio"
                                    name="chest"
                                    id="D"
                                    value="D"
                                    required
                                      />
                                   <label for="D">More than 8cm.</label><br /><br /> -->



                                   <p id="quest">4. Sweat.</p>

                                   <input

                                                                      type="radio"
                                                                      name="joints"
                                                                      id="A"
                                                                      value="A"
                                                                      required
                                                                  />
                                                                  <label for="A">Sweat little but not much. Have minimal body odour.</label><br />
                                                                  <input
                                                                      type="radio"
                                                                      name="joints"
                                                                      id="B"
                                                                      value="B"
                                                                      required
                                                                  />
                                                                  <label for="B">Sweat a lot. Have medium body odour.</label><br />
                                                                  <input
                                                                      type="radio"
                                                                      name="joints"
                                                                      id="C"
                                                                      value="C"
                                                                      required
                                                                  />
                                                                  <label for="C">Sweat moderately but sweat a lot when working hard. Have strong body odour.</label><br />
                                                              <!--    <input
                                                                   type="radio"
                                                                   name="joints"
                                                                   id="D"
                                                                   value="D"
                                                                   required
                                                                     />
                                                                  <label for="D">Yes ,it is paining but dur to an injury.</label><br /><br /> -->


     <p id="quest">5. Appetite</p>

      <input

                                                                       type="radio"
                                                                       name="chest_pain"
                                                                       id="A"
                                                                       value="A"
                                                                       required
                                                                   />
                                                                   <label for="A">Irregular, sometimes i fill hungry sometimes I don't.</label><br />
                                                                   <input
                                                                       type="radio"
                                                                       name="chest_pain"
                                                                       id="B"
                                                                       value="B"
                                                                       required
                                                                   />
                                                                   <label for="B">Strong and sharp, always feel hungry.</label><br />
                                                                   <input
                                                                       type="radio"
                                                                       name="chest_pain"
                                                                       id="C"
                                                                       value="C"
                                                                       required
                                                                   />
                                                                   <label for="C">Decent appetite, have tendency to eat for comfort and taste.</label><br />
                                                             <!--      <input
                                                                    type="radio"
                                                                    name="chest_pain"
                                                                    id="D"
                                                                    value="D"
                                                                    required
                                                                      />
                                                                   <label for="D">No , I am not feeling any pain in chest.</label><br /><br /> -->


                 <p id="quest">6. Skin</p>

                 <input
                                                                                    type="radio"
                                                                                    name="water"
                                                                                    id="A"
                                                                                    value="A"
                                                                                    required
                                                                                />
                                                                                <label for="A">Normal to dry, rough, thin and cool. Skin issues like dryness, dullness and wrinkly .</label><br />
                                                                                <input
                                                                                    type="radio"
                                                                                    name="water"
                                                                                    id="B"
                                                                                    value="B"
                                                                                    required
                                                                                />
                                                                                <label for="B">Normal to oily, soft, reddish, sensitive and warm. Skin issues like inflammation .</label><br />
                                                                                <input
                                                                                    type="radio"
                                                                                    name="water"
                                                                                    id="C"
                                                                                    value="C"
                                                                                    required
                                                                                />
                                                                                <label for="C">Normal to oily, soft, thick, and cool. Skin issues like excessive oily itching , fungal infections.</label><br />
                                                                           <!--     <input
                                                                                 type="radio"
                                                                                 name="water"
                                                                                 id="D"
                                                                                 value="D"
                                                                                 required
                                                                                   />
                                                                                <label for="D">More than 8 glass.</label><br /><br />  -->


      <p id="quest">7. Hair</p>

       <input
                                                                                      type="radio"
                                                                                      name="work"
                                                                                      id="A"
                                                                                      value="A"
                                                                                      required
                                                                                  />
                                                                                  <label for="A">Rough, dry and wavy. I get split end ends easily.</label><br />
                                                                                  <input
                                                                                      type="radio"
                                                                                      name="work"
                                                                                      id="B"
                                                                                      value="B"
                                                                                      required
                                                                                  />
                                                                                  <label for="B">Normal, straight, thin and brownish.</label><br />
                                                                                  <input
                                                                                      type="radio"
                                                                                      name="work"
                                                                                      id="C"
                                                                                      value="C"
                                                                                      required
                                                                                  />
                                                                                  <label for="C">Thick, curly and oily. Hair color tends to be on darker side.</label><br />
                                                                        <!--          <input
                                                                                   type="radio"
                                                                                   name="work"
                                                                                   id="D"
                                                                                   value="D"
                                                                                   required
                                                                                     />
                                                                                  <label for="D">After 4.5 hrs.</label><br /><br />  -->


         <p id="quest">8. Lips & Teeth</p>

          <input
                                                                                           type="radio"
                                                                                           name="muscle"
                                                                                           id="A"
                                                                                           value="A"
                                                                                           required
                                                                                       />
                                                                                       <label for="A">Have thin lips that tends to get dry. Teeth can be somehow uneven. Teeth may require constant attention.</label><br />
                                                                                       <input
                                                                                           type="radio"
                                                                                           name="muscle"
                                                                                           id="B"
                                                                                           value="B"
                                                                                           required
                                                                                       />
                                                                                       <label for="B">Medium sized soft lips. Upper lips slightly darker than lower lip. Teeth are medium sized but I tend to suffer from cavities.</label><br />
                                                                                       <input
                                                                                           type="radio"
                                                                                           name="muscle"
                                                                                           id="C"
                                                                                           value="C"
                                                                                           required
                                                                                       />
                                                                                       <label for="C">Large and smooth lips. Teeth are well aligned and require less are in general.</label><br />
                                                                               <!--        <input
                                                                                        type="radio"
                                                                                        name="muscle"
                                                                                        id="D"
                                                                                        value="D"
                                                                                        required
                                                                                          />
                                                                                       <label for="D">No ,I don't feel any noticable pain.</label><br /><br /> -->





 <p id="quest">9. Eyes</p>

          <input
                                                                                           type="radio"
                                                                                           name="eyes"
                                                                                           id="A"
                                                                                           value="A"
                                                                                           required
                                                                                       />
                                                                                       <label for="A">Small in size. Feel dry and sleepy eyes often I blink a lot.</label><br />
                                                                                       <input
                                                                                           type="radio"
                                                                                           name="eyes"
                                                                                           id="B"
                                                                                           value="B"
                                                                                           required
                                                                                       />
                                                                                       <label for="B">Medium in size. I often get reddish eyes.</label><br />
                                                                                       <input
                                                                                           type="radio"
                                                                                           name="eyes"
                                                                                           id="C"
                                                                                           value="C"
                                                                                           required
                                                                                       />
                                                                                       <label for="C">Big and attractive. I have thick eye lashes.</label><br />




  <p id="quest">10. General signs</p>

           <input
                                                                                            type="radio"
                                                                                            name="gs"
                                                                                            id="A"
                                                                                            value="A"
                                                                                            required
                                                                                        />
                                                                                        <label for="A">Cracking sound in joints. Small forehead. Nails crack easily.</label><br />
                                                                                        <input
                                                                                            type="radio"
                                                                                            name="gs"
                                                                                            id="B"
                                                                                            value="B"
                                                                                            required
                                                                                        />
                                                                                        <label for="B">Black moles on body. Medium forehead. Nails are pink and soft.</label><br />
                                                                                        <input
                                                                                            type="radio"
                                                                                            name="gs"
                                                                                            id="C"
                                                                                            value="C"
                                                                                            required
                                                                                        />
                                                                                        <label for="C">Disproportionate body like heavy thighs, his etc. Large forehead. Nails are wide and whitish.</label><br />









    <input type="submit" value="Check Dosha" name="submit" />
